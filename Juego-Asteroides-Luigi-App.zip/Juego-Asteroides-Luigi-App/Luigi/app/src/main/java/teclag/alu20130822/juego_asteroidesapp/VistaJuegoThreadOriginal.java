package teclag.alu20130822.juego_asteroidesapp;

import android.util.Log;

public class VistaJuegoThreadOriginal extends Thread {

    private VistaJuegoViewOriginal vistaJuegoViewOriginal;
    private int            periodoSleep;

    public VistaJuegoThreadOriginal(VistaJuegoViewOriginal vistaJuegoViewOriginal, int periodo) {
        super();
        this.vistaJuegoViewOriginal = vistaJuegoViewOriginal;
        periodoSleep = periodo;
    }

    @Override
    public void run () {
        boolean corriendo = vistaJuegoViewOriginal.isCorriendo();
        while ( corriendo ) {
            corriendo = vistaJuegoViewOriginal.isCorriendo();
            vistaJuegoViewOriginal.actualizarFisica();
            try {
                Thread.sleep( periodoSleep );
            } catch (InterruptedException ex) {
                Log.e( "Asteriodes", ex.toString() );
            }
        }
    }

}
