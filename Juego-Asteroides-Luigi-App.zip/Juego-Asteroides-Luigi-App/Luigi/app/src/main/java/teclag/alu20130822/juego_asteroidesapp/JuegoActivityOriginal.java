package teclag.alu20130822.juego_asteroidesapp;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class JuegoActivityOriginal extends AppCompatActivity {

    private  VistaJuegoViewOriginal vistaJuegoViewOriginal;
    private MediaPlayer mPlayAudioFondo;
    private MediaPlayer mPlayAudioDisparo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.juego_layout_original);
        this.setVolumeControlStream( AudioManager.STREAM_MUSIC );

        vistaJuegoViewOriginal = findViewById( R.id.vistaJuegoViewOriginal );

        mPlayAudioFondo = MediaPlayer.create( this, R.raw.audio_fondo);
        mPlayAudioFondo.setLooping ( true );

        mPlayAudioDisparo = MediaPlayer.create( this, R.raw.audio_disparo);
        vistaJuegoViewOriginal.setmPlayAudioDisparo( mPlayAudioDisparo );
    }

    @Override
    protected void onResume() {
        super.onResume();
        if( mPlayAudioFondo != null) {
            mPlayAudioFondo.start();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if( mPlayAudioFondo != null) {
            mPlayAudioFondo.pause();
        }
    }

    @Override
    protected void onDestroy() {
        if (mPlayAudioFondo != null ) {
            mPlayAudioFondo.stop();
        }
        if ( mPlayAudioDisparo != null ) {
            mPlayAudioDisparo.stop();
        }

        vistaJuegoViewOriginal.setCorriendo( false );
        vistaJuegoViewOriginal.guardarScore();
        VistaJuegoThreadOriginal hilo = vistaJuegoViewOriginal.getVistaJuegoThreadOriginal();
        try {
            hilo.join();
        } catch ( InterruptedException ex) {
            Log.e("Asteroides", ex.toString() );
        }

        super.onDestroy();
    }
}