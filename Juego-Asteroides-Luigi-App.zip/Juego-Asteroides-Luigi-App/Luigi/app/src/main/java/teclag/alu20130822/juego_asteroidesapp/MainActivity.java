package teclag.alu20130822.juego_asteroidesapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    LinearLayout layout;
    private Class<?> selectedActivity = JuegoActivityOriginal.class; // Actividad por defecto



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        layout = (LinearLayout) findViewById ( R.id.id_layout );

    }

    // Creamos el menu de la Actividad que aparecerá en la barra de acciones (ActionBar)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate ( R.menu.menu_layout, menu );
        return super.onCreateOptionsMenu(menu);
    }


    public void onClickJugar(MenuItem item) {
        Intent i = new Intent(this, selectedActivity);
        startActivity(i);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.tema_default || id == R.id.tema_mario) {

            if (id == R.id.tema_default) {
                selectedActivity = JuegoActivityOriginal.class;
            } else if (id == R.id.tema_mario) {
                selectedActivity = JuegoActivity.class;
            }

            item.setChecked(true); // Marcar la opción seleccionada como chequeada
        }

        return true;
    }
    public void onClickScores(MenuItem item) {
            Intent intent  = new Intent ( this, ScoresActivity.class );
            startActivity ( intent );

    }

    public void onClickAcercaDe(MenuItem item) {
        View layout = getLayoutInflater().inflate ( R.layout.acercade_layout, null );

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(this.getString(R.string.leyenda_acercade))
                .setIcon(R.drawable.itl)
                .setView(layout)
                .setPositiveButton(this.getString(R.string.leyenda_acercadeaceptar), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        mostrarToast(getString(R.string.toast_acercade));

                    }
                })
                .setCancelable(false)
                .create()
                .show();
    }

    public void mostrarToast ( String mensaje ) {
        Toast.makeText( this, mensaje, Toast.LENGTH_SHORT ).show();

    }

    public void onClickSalir(MenuItem item) {
        // Implementa la acción para el menú "Salir"
        finish();
    }

    @Override
    public void onBackPressed () {
        // Hacer nada cuando se pulse el boton ATRAS del dispositivo
        Toast.makeText ( this, "Use la opcion Salir del menu", Toast.LENGTH_SHORT ).show ();
    }

}
