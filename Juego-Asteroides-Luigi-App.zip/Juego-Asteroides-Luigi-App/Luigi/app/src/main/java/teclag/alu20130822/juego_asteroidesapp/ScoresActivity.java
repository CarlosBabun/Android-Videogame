package teclag.alu20130822.juego_asteroidesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import android.widget.ArrayAdapter;


public class ScoresActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> logList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scores);

        listView = findViewById(R.id.listView);
        logList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, logList);
        listView.setAdapter(adapter);

        scores();
    }

    public void scores() {
        if (isAlmExtLeible()) {
            // Obtener la ruta raiz del almacenamiento externo
            File rutaExt = Environment.getExternalStorageDirectory();

            // Formamos la ruta donde esta guardado el archivo, en este caso en la carpeta DCIM
            String rutaArchivo = rutaExt.getAbsolutePath() + "/DCIM";

            // Asociamos un File para el archivo en la ruta anterior
            File archivo = new File(rutaArchivo, "log.txt");

            // Abrimos, leemos y cerramos el archivo
            try {
                BufferedReader br = new BufferedReader(
                        new FileReader(archivo));

                String linea;
                logList.clear();
                while ((linea = br.readLine()) != null) {
                    logList.add(linea);
                }
                br.close();
                adapter.notifyDataSetChanged();
            } catch (IOException ex) {
                Toast.makeText(this, "ERROR: " + ex, Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "El almacenamiento externo no está habilitado para SOLO LECTURA", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean isAlmExtLeible() {
        String estado = Environment.getExternalStorageState();
        return estado.equals(Environment.MEDIA_MOUNTED) || estado.equals(Environment.MEDIA_MOUNTED_READ_ONLY);
    }
}


