/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                                CAMPUS LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                             DESARROLLO EN ANDROID "A"
:*
:*                   SEMESTRE: ENE-JUN/2024    HORA: 08-09 HRS
:*
:*             Activity que muestra el Splash para la aplicación del IMC
:*
:*  Autor       : Carlos Francisco Babún Ravelo    #20130822
:*  Fecha       : 12/03/2024
:*  Compilador  : Android Studio Hedgehog
:*  Descripcion : Este activity muestra un breve Splash con un
:*                icono/imagen del proyecto, esto antes de dar el acceso
:*                al usuario a la aplicación principal del calculo de IMC.
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*==========================================================================================
:*
:*------------------------------------------------------------------------------------------*/
package teclag.alu20130822.juego_asteroidesapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        //Hacer la transición al MainActivity después de 2 segundos.
        new Handler ().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent( SplashActivity.this , MainActivity.class );
                startActivity( intent );
                finish(); //Terminar el Splash Activity
            }
        }, 2000);
    }
}