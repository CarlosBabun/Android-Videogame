package teclag.alu20130822.juego_asteroidesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;

public class JuegoActivity extends AppCompatActivity {

    private  VistaJuegoView vistaJuegoView;
    private MediaPlayer mPlayAudioFondo;
    private MediaPlayer mPlayAudioDisparo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.juego_layout);   
        this.setVolumeControlStream( AudioManager.STREAM_MUSIC );

        vistaJuegoView = findViewById( R.id.vistaJuegoView );

        mPlayAudioFondo = MediaPlayer.create( this, R.raw.thememario);
        mPlayAudioFondo.setLooping ( true );

        mPlayAudioDisparo = MediaPlayer.create( this, R.raw.flop);
        vistaJuegoView.setmPlayAudioDisparo( mPlayAudioDisparo );
    }

    @Override
    protected void onResume() {
        super.onResume();
        if( mPlayAudioFondo != null) {
            mPlayAudioFondo.start();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if( mPlayAudioFondo != null) {
            mPlayAudioFondo.pause();
        }
    }

    @Override
    protected void onDestroy() {
        if (mPlayAudioFondo != null ) {
            mPlayAudioFondo.stop();
        }
        if ( mPlayAudioDisparo != null ) {
            mPlayAudioDisparo.stop();
        }

        vistaJuegoView.setCorriendo( false );
        vistaJuegoView.guardarScore();
        VistaJuegoThread hilo = vistaJuegoView.getVistaJuegoThread();
        try {
            hilo.join();
        } catch ( InterruptedException ex) {
            Log.e("Asteroides", ex.toString() );
        }

        super.onDestroy();
    }
}